const express = require('express');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const app = express();

const db = new sqlite3.Database('./notes.db', (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to SQLite database.');
        console.log('Database file path:', require('path').resolve('./notes.db'));
        db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='notes'", (err, row) => {
            if (err) {
                console.error('Error checking table existence:', err);
            } else if (!row) {
                console.log('Creating notes table...');
                db.run(`CREATE TABLE notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL
                )`, (err) => {
                    if (err) {
                        console.error('Error creating table:', err.message);
                    } else {
                        console.log('Notes table created.');
                    }
                });
            } else {
                console.log('Notes table already exists.');
                db.get('SELECT COUNT(*) as count FROM notes', (err, row) => {
                    if (err) {
                        console.error('Error checking table:', err);
                    } else {
                        console.log('Notes in database:', row.count);
                    }
                });
            }
        });
    }
});

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

const page = (title, content = '', back = '/') => `
<!DOCTYPE html>
<html>
<head>
  <title>${title}</title>
  <link rel="stylesheet" href="/style.css">
</head>
<body>
<nav>
  <a href="/">Home</a> |
  <a href="/notes">Notes</a> |
  <a href="/contact">Contact</a>
</nav>
<div class="container">
  <h2>${title}</h2>
  ${content}
  <a href="${back}">Back</a>
</div>
</body>
</html>
`;

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/views/index.html');
});

app.get('/notes', (req, res) => {
    res.sendFile(__dirname + '/views/notes.html');
});

app.get('/api/notes', (req, res) => {
    console.log('GET /api/notes called');
    db.all('SELECT * FROM notes ORDER BY id ASC', [], (err, rows) => {
        console.log('Database query result:', err, rows);
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(rows);
    });
});

app.get('/api/notes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid id' });
    }
    
    db.get('SELECT * FROM notes WHERE id = ?', [id], (err, row) => {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }
        if (!row) {
            return res.status(404).json({ error: 'Note not found' });
        }
        res.json(row);
    });
});

app.post('/api/notes', (req, res) => {
    const { title, content } = req.body;
    if (!title || !content) {
        return res.status(400).json({ error: 'Missing required fields: title and content' });
    }
    
    db.run('INSERT INTO notes (title, content) VALUES (?, ?)', [title, content], function(err) {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }
        res.status(201).json({ id: this.lastID, title, content });
    });
});

app.put('/api/notes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid id' });
    }
    
    const { title, content } = req.body;
    if (!title || !content) {
        return res.status(400).json({ error: 'Missing required fields: title and content' });
    }
    
    db.run('UPDATE notes SET title = ?, content = ? WHERE id = ?', [title, content, id], function(err) {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Note not found' });
        }
        res.json({ id, title, content });
    });
});

app.delete('/api/notes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid id' });
    }
    
    db.run('DELETE FROM notes WHERE id = ?', [id], function(err) {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Note not found' });
        }
        res.status(200).json({ message: 'Note deleted successfully' });
    });
});

app.get('/contact', (req, res) => {
    res.sendFile(__dirname + '/views/contact.html');
});

app.post('/contact', (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !message) {
        return res.status(400).send(page('400 — Missing form fields', '', '/contact'));
    }

    const data = { name, email: email || '', message, date: new Date() };

    console.log('Contact form submitted:', data);

    fs.writeFile('contacts.json', JSON.stringify(data, null, 2), err => {
        if (err) return res.status(500).send('Error saving data');
        res.send(page(`Thanks, ${name}! Your message has been saved.`));
    });
});

app.get('/api/info', (req, res) => {
    res.json({
        project: 'NotesApp',
        authors: ['Nurym', 'Iskander'],
        version: '2.1.0'
    });
});

app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
        res.status(404).json({ error: 'API endpoint not found' });
    } else {
        res.status(404).send(page('404 — Page not found'));
    }
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});