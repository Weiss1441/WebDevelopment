# Notes App
Notes App is a simple web application for creating and managing personal notes.

## Team Members
- Nurym 
- Iskander 
- Group SE-2427

## Project Topic
This project focuses on building a basic notes application where users can
create, edit, and delete notes. The application will be extended step by step
during the course.

## Database
- **Database**: SQLite
- **Table**: notes
- **Structure**:
  - `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
  - `title` (TEXT NOT NULL)
  - `content` (TEXT NOT NULL)

## Available Routes

### `/` – Home Page
- Main page of the application
- Contains navigation links to all pages
- Includes API test links

---

### `/notes`
- Notes management page
- Create, read, update, and delete notes through web interface
- Uses the API endpoints internally

---

### `/contact` (POST)
- Handles form submission
- Server-side validation:
  - Missing required fields → **HTTP 400**
- Submitted data:
  - Logged in the terminal
  - Saved to `contacts.json`

---

### `/api/info`
- Returns project information in **JSON format**

---

## API Routes (CRUD for Notes)

### `GET /api/notes`
- Returns all notes in JSON format
- Sorted by id ASC
- Status: 200 OK

### `GET /api/notes/:id`
- Returns a single note by id
- Validation: id must be a valid number
- Status: 200 OK, 400 Bad Request (invalid id), 404 Not Found

### `POST /api/notes`
- Creates a new note
- Body: `{ "title": "string", "content": "string" }`
- Validation: title and content are required
- Status: 201 Created, 400 Bad Request

### `PUT /api/notes/:id`
- Updates an existing note by id
- Body: `{ "title": "string", "content": "string" }`
- Validation: id must be valid number, title and content required
- Status: 200 OK, 400 Bad Request, 404 Not Found

### `DELETE /api/notes/:id`
- Deletes a note by id
- Validation: id must be a valid number
- Status: 200 OK, 400 Bad Request, 404 Not Found

## Installation & Run
```bash
npm install
node server.js
```
After running the server, open your browser and go to: http://localhost:3000

## Team Member Contributions
- Nurym: [Contributions]
- Iskander: [Contributions]
